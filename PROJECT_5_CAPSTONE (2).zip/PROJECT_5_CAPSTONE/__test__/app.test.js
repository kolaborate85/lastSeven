const app = require ('../src/server/app');
const jest = require('jest');