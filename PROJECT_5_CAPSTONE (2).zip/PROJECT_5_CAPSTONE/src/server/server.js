const app = require('./app');

const localserver = app.listen(port, callback);

function callback(){
    console.log("server is testing");
    console.log(`runing localhost: ${port}`);

}

